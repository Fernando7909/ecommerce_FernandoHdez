const functions = require('firebase-functions');
const stripe = "sk_test_51QSgOrLqhhGqu8RPiYc4CASf4JSGP0Rj3PpPf39pMVg5RY2jm0O1PlMRt27rz8lo8eNY20TNZIS9plvzCnYBXO5z00IDIK26w6";
 
exports.createCheckoutSession = functions.https.onRequest(async (req, res) => {
  try {
    const session = await stripe.checkout.sessions.create({
      payment_method_types: ['card'],
      line_items: req.body.items.map((item) => ({
        price_data: {
          currency: 'eur',
          product_data: {
            name: item.name,
          },
          unit_amount: item.price * 100, // Convertir a cèntims
        },
        quantity: item.quantity,
      })),
      mode: 'payment',
      success_url: `${req.headers.origin}/success`,
      cancel_url: `${req.headers.origin}/cancel`,
    });
 
    res.status(200).send({ sessionId: session.id });
  } catch (error) {
    console.error(error);
    res.status(500).send({ error: 'Error creating checkout session' });
  }
});
