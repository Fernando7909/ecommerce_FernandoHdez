import { initializeApp } from "firebase/app";
import { getFirestore } from "firebase/firestore";
import { getAuth } from "firebase/auth";
 

// Your web app's Firebase configuration
const firebaseConfig = {
    apiKey: "AIzaSyBhcs9IKgovoOPoa4Mn7PjnvzVhCgDIXmU",
    authDomain: "ecommerce-fernando.firebaseapp.com",
    projectId: "ecommerce-fernando",
    storageBucket: "ecommerce-fernando.firebasestorage.app",
    messagingSenderId: "125879419652",
    appId: "1:125879419652:web:2809316c7b7dd1ddfdc651"
  };

// Initialize Firebase
const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = getFirestore(app);
 
